package com.example.warehouseapp.model;

public interface IWarehouseAdapterItem {
    int objectIdentifier();
}
