package com.example.warehouseapp.model;

public interface IDeleteShipmentModel {
    void deleteShipment(Shipment shipment);
}
