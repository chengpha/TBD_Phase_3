package com.example.warehouseapp.views;

public interface IDisplayAllShipmentView {
}
